<?php
$api_key = 'dd82f80e2c0746c16a975884a73b73b5'; // your api key
$amount = $_REQUEST["amount"]; //rial
$callback = 'https://poolam.ir/test/terminal/processTransaction.php'; // callback url

include_once("functions.php");
$result = request($api_key,$amount,urlencode($callback));
$result = json_decode($result,1);
if($result['status'] == 1) {
    $invoice_key = $result['invoice_key']; // you may save this in DB and check it in get.php for more security
    $go = "https://poolam.ir/invoice/pay/".$invoice_key;
    header('location:'.$go);
} else {
    echo 'error : '.$result['errorCode'].' - '.$result['errorDescription'];
    die('');
}
?>
