<?php
$api_key = 'dd82f80e2c0746c16a975884a73b73b5'; // your api key

include_once("functions.php");
$invoice_key = @$_POST['invoice_key'];
/**
* if your saved invoice_key from request method in your Database
* you can compare it to invoice_key which passed through post method here
* this way you can make sure that user is not passing fake data to your server
*/
$result = check($api_key, $invoice_key);
$result = json_decode($result,1);
if($result['status'] == 1) {
        echo 'bank refrence : '.$result['bank_code'];
} else {
    echo $result['errorCode'] ;
    echo $result['errorDescription'];
    echo 'عملیات پرداخت آنلاین موفقیت آمیز نبوده است!';
}
?>
