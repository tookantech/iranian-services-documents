<?php
	error_reporting(0);
	
    $Username = 'Your Username';
    $Password = 'Your Password';    
    $merchantConfigID = 'Your merchantConfigID';
?>	