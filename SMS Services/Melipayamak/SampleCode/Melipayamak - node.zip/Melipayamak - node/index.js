let MelipayamakApi = require('./src/melipayamak');

module.exports = MelipayamakApi;